package poligonos;

public interface Poligono {
	
	public double area();

}
